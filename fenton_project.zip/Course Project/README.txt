Course Project README

INSTRUCTIONS
1. Create virtual Environment
2. Install Flask
3. set FLASK_APP=courseProject.py
4. Run Flask
5. go to http://127.0.0.1:5000/

REQUIREMENTS
*Flask
*Python
*Web Browser

FILES & DIRECTORIES
* courseProject.py
* homePage.html
* galleryPage.html
* aboutPage.html
* index.html
* nav.html
* style.css
* image1.jpeg
* about-img.jpg