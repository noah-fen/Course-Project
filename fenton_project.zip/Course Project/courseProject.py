from flask import Flask, redirect, url_for, render_template, request, send_from_directory

app = Flask(__name__)

# link extension to the home page
@app.route("/")
def home():
    return render_template("homePage.html")

# link extension to the gallery page
@app.route("/gallery")
def gallery():
    return render_template("galleryPage.html")

# link extension to the about page
@app.route("/about")
def about():
    return render_template("aboutPage.html")

if __name__ == "__main__":
    app.run()